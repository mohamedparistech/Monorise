
import { Entity, Point, ShapeType } from './types';

export class GameEngine {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  
  balloon: Entity;
  shield: Entity;
  obstacles: Entity[] = [];
  
  score: number = 0;
  difficulty: number = 1;
  isGameOver: boolean = false;
  
  private lastTime: number = 0;
  private gameStartTime: number = 0;
  private cameraY: number = 0;
  private nextSpawnY: number = 0;
  private firstSpawnDone: boolean = false;

  // Track shield position in screen space
  private shieldScreenX: number;
  private shieldScreenY: number;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    
    const cw = canvas.width;
    const ch = canvas.height;

    // Balloon starts at the bottom. 
    // Elongated shape (width: 150, height: 210)
    this.balloon = {
      x: cw / 2,
      y: ch - 150,
      vx: 0,
      vy: -1.6,
      width: 150,
      height: 210,
      type: 'balloon'
    };

    // Shield (controlled by player) - Size 48
    this.shield = {
      x: cw / 2,
      y: ch - 250,
      vx: 0,
      vy: 0,
      width: 48,
      height: 48,
      type: 'shield'
    };

    this.shieldScreenX = cw / 2;
    this.shieldScreenY = ch - 250;
    this.cameraY = 0;
    this.nextSpawnY = 0; 
  }

  updateShield(screenX: number, screenY: number) {
    this.shieldScreenX = screenX;
    this.shieldScreenY = screenY;
  }

  private spawnObstacleCluster(y: number) {
    const cw = this.canvas.width;
    
    // Pattern: Scatter of varied shapes
    const types: ShapeType[] = ['square', 'rect', 'circle', 'triangle', 'rotating-rect'];
    const count = 10 + Math.floor(this.difficulty * 4);
    
    for (let i = 0; i < count; i++) {
      const type = types[Math.floor(Math.random() * types.length)];
      const x = Math.random() * cw;
      const py = y - Math.random() * 600;
      
      let width = 30 + Math.random() * 40;
      let height = 30 + Math.random() * 40;
      let vx = 0;
      let rotationSpeed = 0;

      if (type === 'rect') {
        if (Math.random() > 0.5) { width = 140; height = 24; }
        else { width = 24; height = 140; }
      } else if (type === 'rotating-rect') {
        rotationSpeed = (Math.random() - 0.5) * 0.15;
      } else if (type === 'square' && Math.random() > 0.6) {
        vx = (Math.random() - 0.5) * 6;
      }

      const entity: Entity = {
        x, y: py, vx, vy: 0, width, height, type,
        rotation: 0,
        rotationSpeed,
        points: type === 'triangle' ? [
          { x: 0, y: -height/2 },
          { x: -width/2, y: height/2 },
          { x: width/2, y: height/2 }
        ] : undefined
      };
      
      this.obstacles.push(entity);
    }
  }

  update(timestamp: number) {
    if (this.isGameOver) return null;
    if (!this.gameStartTime) this.gameStartTime = timestamp;
    
    const deltaTime = timestamp - this.lastTime;
    this.lastTime = timestamp;
    if (isNaN(deltaTime) || deltaTime > 100) return null;

    const elapsedSeconds = (timestamp - this.gameStartTime) / 1000;

    this.difficulty += 0.0002;
    
    // Move balloon up
    const currentSpeed = -1.6 * (1 + (this.difficulty * 0.1));
    this.balloon.y += currentSpeed;
    this.score = Math.abs(Math.floor(this.balloon.y - (this.canvas.height - 150)));

    // Camera follow - Balloon is now kept at 60% height of screen
    const targetCameraY = this.balloon.y - this.canvas.height * 0.6;
    this.cameraY += (targetCameraY - this.cameraY) * 0.1;

    // Sync Shield
    const prevWorldX = this.shield.x;
    const prevWorldY = this.shield.y;
    this.shield.x = this.shieldScreenX;
    this.shield.y = this.shieldScreenY + this.cameraY;
    this.shield.vx = (this.shield.x - prevWorldX);
    this.shield.vy = (this.shield.y - prevWorldY);

    // DELAY LOGIC: Only spawn and update obstacles after 1.5 seconds
    if (elapsedSeconds < 1.5) {
      return null;
    }

    // First wave spawn exactly at the top of the viewport when delay is reached
    if (!this.firstSpawnDone) {
      this.nextSpawnY = this.cameraY - 100;
      this.spawnObstacleCluster(this.nextSpawnY);
      this.nextSpawnY -= 800;
      this.firstSpawnDone = true;
    }

    // Continuous spawn
    if (this.cameraY < this.nextSpawnY + 600) {
      this.spawnObstacleCluster(this.nextSpawnY);
      this.nextSpawnY -= 800;
    }

    let result: string | null = null;

    // Update Obstacles
    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      const ob = this.obstacles[i];
      
      ob.x += ob.vx;
      ob.y += ob.vy;
      if (ob.rotationSpeed) ob.rotation = (ob.rotation || 0) + ob.rotationSpeed;

      if (ob.vx !== 0 && (ob.x < 0 || ob.x > this.canvas.width)) ob.vx *= -1;

      ob.vx *= 0.98;
      ob.vy *= 0.98;

      // Collision Shield
      if (this.checkCollision(this.shield, ob)) {
        const dx = ob.x - this.shield.x;
        const dy = ob.y - this.shield.y;
        const angle = Math.atan2(dy, dx);
        const force = 8 + Math.abs(this.shield.vx) + Math.abs(this.shield.vy);
        
        ob.vx = Math.cos(angle) * force;
        ob.vy = Math.sin(angle) * force;
        
        const minDist = (this.shield.width + ob.width) / 2;
        ob.x = this.shield.x + Math.cos(angle) * minDist;
        ob.y = this.shield.y + Math.sin(angle) * minDist;
        
        result = 'clink';
      }

      // Collision Balloon
      if (this.checkCollision(this.balloon, ob)) {
        this.isGameOver = true;
        result = 'pop';
      }

      // Garbage collection
      if (ob.y > this.cameraY + this.canvas.height + 500) {
        this.obstacles.splice(i, 1);
      }
    }

    return result;
  }

  private getDistance(a: Point, b: Point): number {
    return Math.sqrt((a.x - b.x)**2 + (a.y - b.y)**2);
  }

  private checkCollision(circle: Entity, target: Entity): boolean {
    const radius = circle.width / 2;

    // Special case for balloon which is elongated
    if (target.type === 'balloon') {
      const closestX = Math.max(target.x - target.width / 2, Math.min(circle.x, target.x + target.width / 2));
      const closestY = Math.max(target.y - target.height / 2, Math.min(circle.y, target.y + target.height / 2));
      const distanceX = circle.x - closestX;
      const distanceY = circle.y - closestY;
      const distanceSquared = (distanceX * distanceX) + (distanceY * distanceY);
      return distanceSquared < (radius * radius);
    }

    if (target.type === 'circle') {
      const dist = this.getDistance(circle, target);
      return dist < (radius + target.width / 2);
    }

    if (target.type === 'triangle' && target.points) {
      return this.isCircleInTriangle(circle.x, circle.y, radius, target);
    }

    const closestX = Math.max(target.x - target.width / 2, Math.min(circle.x, target.x + target.width / 2));
    const closestY = Math.max(target.y - target.height / 2, Math.min(circle.y, target.y + target.height / 2));
    const distanceX = circle.x - closestX;
    const distanceY = circle.y - closestY;
    const distanceSquared = (distanceX * distanceX) + (distanceY * distanceY);
    
    return distanceSquared < (radius * radius);
  }

  private isCircleInTriangle(cx: number, cy: number, r: number, tri: Entity): boolean {
    const pts = tri.points!.map(p => ({ x: tri.x + p.x, y: tri.y + p.y }));
    let p = { x: cx, y: cy };
    const area = Math.abs((pts[0].x*(pts[1].y-pts[2].y) + pts[1].x*(pts[2].y-pts[0].y) + pts[2].x*(pts[0].y-pts[1].y))/2);
    const a1 = Math.abs((p.x*(pts[1].y-pts[2].y) + pts[1].x*(pts[2].y-p.y) + pts[2].x*(p.y-pts[1].y))/2);
    const a2 = Math.abs((pts[0].x*(p.y-pts[2].y) + p.x*(pts[2].y-pts[0].y) + pts[2].x*(pts[0].y-p.y))/2);
    const a3 = Math.abs((pts[0].x*(pts[1].y-p.y) + pts[1].x*(p.y-pts[0].y) + p.x*(pts[0].y-pts[1].y))/2);
    return Math.abs(area - (a1 + a2 + a3)) < 1.0;
  }

  draw() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    const drawY = (y: number) => y - this.cameraY;

    // Balloon (Drawn as Ellipse)
    this.ctx.fillStyle = '#000000';
    this.ctx.beginPath();
    this.ctx.ellipse(
      this.balloon.x, 
      drawY(this.balloon.y), 
      this.balloon.width / 2, 
      this.balloon.height / 2, 
      0, 0, Math.PI * 2
    );
    this.ctx.fill();
    
    // String - 150px length
    this.ctx.strokeStyle = '#000000';
    this.ctx.lineWidth = 1;
    this.ctx.beginPath();
    this.ctx.moveTo(this.balloon.x, drawY(this.balloon.y) + this.balloon.height/2);
    this.ctx.lineTo(this.balloon.x, drawY(this.balloon.y) + this.balloon.height/2 + 150);
    this.ctx.stroke();

    // Obstacles
    this.ctx.fillStyle = '#000000';
    for (const ob of this.obstacles) {
      this.ctx.save();
      this.ctx.translate(ob.x, drawY(ob.y));
      if (ob.rotation) this.ctx.rotate(ob.rotation);

      if (ob.type === 'circle') {
        this.ctx.beginPath();
        this.ctx.arc(0, 0, ob.width / 2, 0, Math.PI * 2);
        this.ctx.fill();
      } else if (ob.type === 'triangle' && ob.points) {
        this.ctx.beginPath();
        this.ctx.moveTo(ob.points[0].x, ob.points[0].y);
        this.ctx.lineTo(ob.points[1].x, ob.points[1].y);
        this.ctx.lineTo(ob.points[2].x, ob.points[2].y);
        this.ctx.closePath();
        this.ctx.fill();
      } else {
        this.ctx.fillRect(-ob.width / 2, -ob.height / 2, ob.width, ob.height);
      }
      this.ctx.restore();
    }

    // Shield
    this.ctx.fillStyle = '#ffffff';
    this.ctx.strokeStyle = '#000000';
    this.ctx.lineWidth = 2;
    this.ctx.beginPath();
    this.ctx.arc(this.shield.x, drawY(this.shield.y), this.shield.width / 2, 0, Math.PI * 2);
    this.ctx.fill();
    this.ctx.stroke();
  }
}
