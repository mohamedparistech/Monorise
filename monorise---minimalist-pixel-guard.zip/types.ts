
export type Point = {
  x: number;
  y: number;
};

export type Velocity = {
  vx: number;
  vy: number;
};

export enum GameStatus {
  START = 'START',
  PLAYING = 'PLAYING',
  GAMEOVER = 'GAMEOVER',
}

export type ShapeType = 'square' | 'rect' | 'circle' | 'triangle' | 'rotating-rect' | 'balloon' | 'shield';

export type Entity = Point & Velocity & {
  width: number;
  height: number;
  type: ShapeType;
  rotation?: number;
  rotationSpeed?: number;
  points?: Point[]; // For triangles
  mass?: number;
};

export interface GameState {
  status: GameStatus;
  score: number;
  highScore: number;
  lastMessage: string;
}
