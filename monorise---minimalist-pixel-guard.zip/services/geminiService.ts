
import { GoogleGenAI } from "@google/genai";

export const getGameOverMessage = async (score: number): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate a very short (max 5 words), cold, and minimalist snarky comment for a player who just lost a minimalist black and white pixel art game with a score of ${score}. Use only lowercase and no punctuation. Format: just the text.`,
      config: {
        temperature: 0.9,
      }
    });
    return response.text?.trim().toLowerCase() || "failure is standard";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "gone too soon";
  }
};
