
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameStatus, GameState } from './types';
import { GameEngine } from './Engine';
import { audioService } from './services/audioService';
import { getGameOverMessage } from './services/geminiService';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>({
    status: GameStatus.START,
    score: 0,
    highScore: parseInt(localStorage.getItem('monorise_highscore') || '0'),
    lastMessage: 'protect the core'
  });

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const requestRef = useRef<number>(null);

  const startGame = useCallback(() => {
    if (!canvasRef.current) return;
    
    audioService.playStart();
    const engine = new GameEngine(canvasRef.current);
    engineRef.current = engine;
    
    setGameState(prev => ({
      ...prev,
      status: GameStatus.PLAYING,
      score: 0,
      lastMessage: ''
    }));
  }, []);

  const handleGameOver = useCallback(async (score: number) => {
    setGameState(prev => {
      const newHigh = Math.max(prev.highScore, score);
      localStorage.setItem('monorise_highscore', newHigh.toString());
      return {
        ...prev,
        status: GameStatus.GAMEOVER,
        score,
        highScore: newHigh,
        lastMessage: 'calculating failure...'
      };
    });

    const msg = await getGameOverMessage(score);
    setGameState(prev => ({ ...prev, lastMessage: msg }));
  }, []);

  const animate = useCallback((time: number) => {
    if (engineRef.current && !engineRef.current.isGameOver) {
      const event = engineRef.current.update(time);
      if (event === 'clink') audioService.playCollision();
      if (event === 'pop') {
        audioService.playPop();
        handleGameOver(engineRef.current.score);
      }
      engineRef.current.draw();
      setGameState(prev => ({ ...prev, score: engineRef.current?.score || 0 }));
      requestRef.current = requestAnimationFrame(animate);
    }
  }, [handleGameOver]);

  useEffect(() => {
    if (gameState.status === GameStatus.PLAYING) {
      requestRef.current = requestAnimationFrame(animate);
    }
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameState.status, animate]);

  const handleInteraction = (e: React.MouseEvent | React.TouchEvent) => {
    if (!engineRef.current || gameState.status !== GameStatus.PLAYING) return;
    
    let clientX, clientY;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const rect = canvasRef.current!.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    
    engineRef.current.updateShield(x, y);
  };

  useEffect(() => {
    const handleResize = () => {
      if (canvasRef.current) {
        canvasRef.current.width = window.innerWidth;
        canvasRef.current.height = window.innerHeight;
      }
    };
    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-white cursor-none select-none touch-none">
      <canvas
        ref={canvasRef}
        onMouseMove={handleInteraction}
        onTouchMove={handleInteraction}
        className="w-full h-full"
      />

      {/* HUD */}
      <div className="absolute top-8 left-0 w-full flex flex-col items-center pointer-events-none">
        <div className="text-4xl text-black font-bold tracking-widest uppercase">
          {Math.floor(gameState.score / 10)}
        </div>
        {gameState.highScore > 0 && (
          <div className="text-sm text-black/40 mt-1 uppercase">
            MAX: {Math.floor(gameState.highScore / 10)}
          </div>
        )}
      </div>

      {/* Overlays */}
      {gameState.status === GameStatus.START && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/90">
          <h1 className="text-7xl text-black font-bold mb-8 tracking-tighter uppercase">MonoRise</h1>
          <button
            onClick={startGame}
            className="px-10 py-4 bg-black text-white text-2xl uppercase hover:bg-white hover:text-black border-2 border-black transition-all active:scale-95"
          >
            Ascend
          </button>
          <div className="mt-12 flex flex-col items-center gap-2 opacity-40">
            <div className="w-8 h-8 rounded-full border-2 border-black bg-white"></div>
            <p className="text-xs uppercase font-bold tracking-widest">Control the white shield</p>
          </div>
        </div>
      )}

      {gameState.status === GameStatus.GAMEOVER && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/95">
          <div className="text-xl text-black/60 mb-2 uppercase italic">"{gameState.lastMessage}"</div>
          <h2 className="text-6xl text-black font-bold mb-2 uppercase">Burst</h2>
          <div className="text-2xl mb-12 uppercase opacity-50">Reached: {Math.floor(gameState.score / 10)}m</div>
          <button
            onClick={startGame}
            className="px-12 py-5 bg-black text-white text-2xl uppercase hover:bg-white hover:text-black border-2 border-black transition-all active:scale-95"
          >
            Retry
          </button>
        </div>
      )}

      {/* Minimalist Border */}
      <div className="absolute inset-0 border-[16px] border-black pointer-events-none opacity-5"></div>
    </div>
  );
};

export default App;
